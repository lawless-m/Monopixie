# GRUB Setup

The binary serves GRUB bootloader files via TFTP but does not bundle them —
they must be copied from a Debian system. The GRUB config itself is generated
dynamically by the binary from your TOML config.

## Directory Structure Expected

```
/srv/pxe/
├── tftp/
│   └── grub/
│       ├── i386-pc/
│       │   └── core.0          ← BIOS network bootloader
│       └── x86_64-efi/
│           └── grubnetx64.efi  ← UEFI network bootloader
└── http/
    ├── grub/
    │   └── grub.cfg            ← NOT needed on disk; served dynamically
    └── debian/
        ├── vmlinuz             ← kernel
        └── initrd.img          ← initrd with iSCSI support
```

## Extracting GRUB Files on Debian

```bash
# Install GRUB network boot support
sudo apt install grub-pc-bin grub-efi-amd64-bin

# BIOS/legacy
sudo grub-mkimage \
  --format=i386-pc-pxe \
  --output=/srv/pxe/tftp/grub/i386-pc/core.0 \
  --prefix='(http,10.11.12.1:8080)/grub' \
  pxe tftp http linux normal configfile

# UEFI x86-64
sudo grub-mkimage \
  --format=x86_64-efi \
  --output=/srv/pxe/tftp/grub/x86_64-efi/grubnetx64.efi \
  --prefix='(http,10.11.12.1:8080)/grub' \
  efinet http linux normal configfile
```

**Important:** The `--prefix` URL must match your `server_ip` and HTTP `port`
from `config.toml`. If you change either, rebuild the GRUB images.

## How grub.cfg is Served

GRUB will request `(http,10.11.12.1:8080)/grub/grub.cfg` over HTTP.
The binary intercepts `GET /grub/grub.cfg` and returns a generated config
built from your TOML values — no static file needed.

The generated config looks like:

```
set timeout=0
set default=0

menuentry "Debian (iSCSI)" {
    linux (http,10.11.12.1:8080)/debian/vmlinuz \
        root=UUID=<uuid-from-config> \
        ip=10.11.12.2::10.11.12.1:255.255.255.0::eth0:none \
        ISCSI_INITIATOR=iqn.2024-01.local.thinclient:initiator \
        ISCSI_TARGET_NAME=iqn.2024-01.local.laptop:debian-thinclient \
        ISCSI_TARGET_IP=10.11.12.1 \
        ISCSI_TARGET_PORT=3260 \
        rd.iscsi.initiator=iqn.2024-01.local.thinclient:initiator \
        quiet
    initrd (http,10.11.12.1:8080)/debian/initrd.img
}
```

## Kernel and Initrd

The kernel and initrd must have iSCSI support compiled in or available as
modules in the initrd. The standard Debian installer initrd includes this.

For a custom initrd, ensure `open-iscsi` or the `iscsi_tcp` kernel module
and `iscsiadm` are present in the initrd environment.

A suitable kernel/initrd pair can be taken directly from:
```bash
/boot/vmlinuz-$(uname -r)
/boot/initrd.img-$(uname -r)
```
on a Debian machine with `open-iscsi` installed.
