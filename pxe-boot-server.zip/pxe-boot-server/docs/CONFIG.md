# Configuration Reference

All configuration lives in a single TOML file passed via `--config`.

## Full Example

```toml
[network]
# The network interface to bind all services to.
# Must be the point-to-point interface connected to the thin client.
interface = "eth0"

# Our IP address on this interface (the server side of the link)
server_ip = "10.11.12.1"

# Subnet mask for the point-to-point link
netmask = "255.255.255.0"

[dhcp]
# The thin client's MAC address. Any DHCP packet from any other MAC is ignored.
client_mac = "AA:BB:CC:DD:EE:FF"

# IP address to assign to the thin client
client_ip = "10.11.12.2"

# Lease time in seconds. Long value is fine — we own this link.
lease_seconds = 86400

[tftp]
# Directory containing GRUB bootloader files.
# See docs/GRUB_SETUP.md for how to populate this.
root = "/srv/pxe/tftp"

# Filename to hand to BIOS (legacy) clients via DHCP option 67
bios_bootfile = "grub/i386-pc/core.0"

# Filename to hand to UEFI x86-64 clients via DHCP option 67
uefi_bootfile = "grub/x86_64-efi/grubnetx64.efi"

# Per-transfer timeout in seconds before retransmit
timeout_seconds = 5

[http]
# Port to serve HTTP on. GRUB config will reference this.
port = 8080

# Directory containing kernel and initrd images.
root = "/srv/pxe/http"

# Path within http root to the kernel image
kernel = "debian/vmlinuz"

# Path within http root to the initrd image
initrd = "debian/initrd.img"

[iscsi]
# These values are injected into the kernel command line.
# The iSCSI target process runs separately and is not managed by this binary.

# IQN of the iSCSI target (on this machine)
target_iqn = "iqn.2024-01.local.laptop:debian-thinclient"

# IP address of the iSCSI target (our server_ip, repeated here for clarity)
target_ip = "10.11.12.1"

# TCP port the iSCSI target listens on (standard is 3260)
target_port = 3260

# LUN to use
lun = 0

# IQN the thin client initiator will identify as
initiator_iqn = "iqn.2024-01.local.thinclient:initiator"
```

## Section Reference

### `[network]`

| Key | Type | Description |
|-----|------|-------------|
| `interface` | string | Interface name to bind to |
| `server_ip` | string | Our IP on the point-to-point link |
| `netmask` | string | Subnet mask |

### `[dhcp]`

| Key | Type | Description |
|-----|------|-------------|
| `client_mac` | string | Thin client MAC (colon-separated hex) |
| `client_ip` | string | IP to assign to thin client |
| `lease_seconds` | integer | DHCP lease duration |

### `[tftp]`

| Key | Type | Description |
|-----|------|-------------|
| `root` | string | Absolute path to TFTP root directory |
| `bios_bootfile` | string | Bootfile for BIOS/legacy clients |
| `uefi_bootfile` | string | Bootfile for UEFI x86-64 clients |
| `timeout_seconds` | integer | Retransmit timeout per block |

### `[http]`

| Key | Type | Description |
|-----|------|-------------|
| `port` | integer | TCP port for HTTP server |
| `root` | string | Absolute path to HTTP root directory |
| `kernel` | string | Kernel path relative to HTTP root |
| `initrd` | string | Initrd path relative to HTTP root |

### `[iscsi]`

| Key | Type | Description |
|-----|------|-------------|
| `target_iqn` | string | IQN of the iSCSI target |
| `target_ip` | string | IP address of the iSCSI target |
| `target_port` | integer | TCP port of the iSCSI target |
| `lun` | integer | LUN number |
| `initiator_iqn` | string | IQN the client initiator will use |
| `root_uuid` | string | UUID of the filesystem inside the iSCSI image (used for `root=UUID=...` kernel arg). Find with `sudo blkid /path/to/image.img` |
