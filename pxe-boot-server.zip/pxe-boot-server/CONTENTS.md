# Contents

Design documentation for `pxe-boot-server` — a single Rust binary providing
DHCP, TFTP, and HTTP to PXE boot a Dell thin client into Debian Linux over a
point-to-point Ethernet cable, with iSCSI root served by a separate process.

## Start Here

→ `README.md` — overview and boot sequence

## Documents

| File | Purpose |
|------|---------|
| `README.md` | Project overview, boot sequence, quick start |
| `config.example.toml` | Annotated example configuration file |
| `docs/ARCHITECTURE.md` | Module structure, runtime model, dependencies — **give this to Claude Code first** |
| `docs/CONFIG.md` | Full TOML configuration reference |
| `docs/GRUB_SETUP.md` | How to build GRUB network boot images and directory layout |
| `docs/ISCSI_KERNEL_ARGS.md` | Kernel command-line iSCSI parameters explained |

## For Claude Code

Start with `docs/ARCHITECTURE.md` then `docs/CONFIG.md`.
The implementation order should be:

1. `config.rs` — get the TOML structures right first
2. `bootconfig.rs` — pure function, easy to unit test
3. `http.rs` — static files + the one dynamic grub.cfg endpoint
4. `tftp.rs` — hand-rolled UDP, read-only
5. `dhcp.rs` — hand-rolled UDP, BIOS/UEFI detection via option 93
6. `main.rs` — wire everything together, task spawning, error propagation
