# Architecture

## Crate Layout

Single binary crate. No workspaces needed at this scale.

```
src/
├── main.rs          — entry point, config loading, tokio runtime, task spawning
├── config.rs        — TOML config structures (serde)
├── dhcp.rs          — DHCP server (UDP/67)
├── tftp.rs          — TFTP server (UDP/69)
├── http.rs          — HTTP server (TCP, configurable port)
└── bootconfig.rs    — GRUB config generation from TOML values
```

## Runtime Model

Tokio multi-threaded runtime. Three long-running tasks spawned from main:

```rust
tokio::spawn(dhcp::run(config.clone()));
tokio::spawn(tftp::run(config.clone()));
tokio::spawn(http::run(config.clone()));
```

All tasks share an `Arc<Config>`. None need to communicate with each other.
If any task exits with an error the process exits (via a JoinSet or
`tokio::select!` on the task handles).

## Module Responsibilities

### main.rs
- Parse CLI args (`--config <path>`)
- Load and validate TOML config
- Bind early to privileged ports before any optional privilege drop
- Spawn the three service tasks
- Wait; propagate any task panic/error as a non-zero exit

### config.rs
- `Config` struct derived from `serde::Deserialize`
- Sub-structs: `NetworkConfig`, `DhcpConfig`, `TftpConfig`, `HttpConfig`, `IscsiConfig`
- Validation logic (IP address consistency, path existence checks) runs after
  deserialisation in a `Config::validate(&self) -> Result<()>` method

### dhcp.rs
- Binds a UDP socket to `0.0.0.0:67` on the configured interface
- Listens for DHCPDISCOVER and DHCPREQUEST packets only
- Matches source MAC against the single configured client MAC
- Ignores any packet from an unknown MAC (log at debug level)
- Responds with a minimal DHCPOFFER / DHCPACK containing:
  - `yiaddr` — client IP from config
  - `siaddr` — server IP (our address on the point-to-point link)
  - Option 66 (TFTP server name) — server IP as string
  - Option 67 (bootfile name) — BIOS or UEFI GRUB filename
    (detected by examining the client's Option 93 / architecture field)
  - Option 51 (lease time) — long value, e.g. 24 hours; we don't care about expiry
  - Option 54 (server identifier)

BIOS vs UEFI detection via DHCP Option 93 (Client System Architecture):
- `0x0000` → BIOS → serve `pxelinux.0` or `grub/i386-pc/core.0`
- `0x0007` → EFI x86-64 → serve `grub/x86_64-efi/grubnetx64.efi`

### tftp.rs
- Binds UDP socket to `0.0.0.0:69`
- Handles only RRQ (read request) packets — no write support
- Each RRQ spawns a short-lived tokio task that:
  - Resolves the requested filename against the configured TFTP root
  - Rejects any path traversal attempts (canonicalise and check prefix)
  - Sends the file in 512-byte blocks (or negotiated blksize via OACK)
  - Handles ACK / retransmit with a configurable timeout
- TFTP is inherently simple; no external crate dependency required
  unless a well-maintained async one exists and is lighter than hand-rolling

### http.rs
- Uses `axum` for simplicity
- Serves static files from the configured HTTP root directory
- One route: `GET /*path` → file from HTTP root
- Path traversal protection via same canonicalise-and-check-prefix approach
- Additionally exposes one generated endpoint:
  - `GET /grub/grub.cfg` — returns dynamically generated GRUB config
    (see bootconfig.rs); not read from disk, generated in memory at request time

### bootconfig.rs
- Pure function: `generate_grub_cfg(config: &Config) -> String`
- Builds a GRUB config containing:
  - `set timeout=0` (boot immediately, no menu needed)
  - `menuentry` with:
    - `linux` line: path to kernel on HTTP server + kernel args
    - `initrd` line: path to initrd on HTTP server
- Kernel args include:
  - Standard: `root=/dev/sda ro quiet` (sda will be the iSCSI device)
  - iSCSI: derived from `[iscsi]` config section (see ISCSI_KERNEL_ARGS.md)
  - `ip=<client_ip>::<server_ip>:<netmask>::eth0:none` for initrd network setup
  - `root=UUID=<root_uuid>` using the UUID from the `[iscsi]` config section

## Key Dependencies

| Crate | Purpose |
|-------|---------|
| `tokio` | Async runtime (full features) |
| `serde` + `serde_derive` | Config deserialisation |
| `toml` | TOML parsing |
| `axum` | HTTP server |
| `tracing` + `tracing-subscriber` | Structured logging |
| `anyhow` | Error handling |
| `clap` | CLI argument parsing |

DHCP and TFTP are hand-rolled against `tokio::net::UdpSocket`.
No external DHCP or TFTP crate dependency — both protocols are simple enough
and external crates add surface area for a project this focused.

## Error Handling Strategy

- Config errors: fatal, printed to stderr, exit 1
- Service bind errors: fatal (ports in use, permissions)
- Per-request errors (bad TFTP path, unknown MAC): logged, request dropped
- Task crashes: caught in main, logged, process exits non-zero

## Logging

`tracing` with `tracing-subscriber` (env-filter). Default level `info`.
Override with `RUST_LOG=debug pxe-boot-server` for packet-level detail.

Notable log events:
- Startup: each service bind address
- DHCP: every DISCOVER/REQUEST received (MAC, client arch), every OFFER/ACK sent
- TFTP: every RRQ (filename, client IP), completion or error
- HTTP: standard axum request logging
- Config generation: logged once at startup for inspection
