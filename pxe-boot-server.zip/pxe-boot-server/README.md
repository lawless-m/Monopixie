# pxe-boot-server

A single Rust binary providing DHCP, TFTP, and HTTP services to PXE boot a
Dell thin client into Debian Linux over a point-to-point Ethernet connection.
The root filesystem is served by a separate iSCSI target process; this binary
only supplies the connection details via kernel command-line parameters.

## Overview

```
Laptop (server)                    Dell Thin Client
┌─────────────────────────┐        ┌──────────────────┐
│  pxe-boot-server        │        │                  │
│  ├─ DHCP  (UDP 67)  ────┼────────┼── PXE ROM        │
│  ├─ TFTP  (UDP 69)  ────┼────────┼── GRUB loader    │
│  └─ HTTP  (TCP 8080)────┼────────┼── kernel + initrd│
│                         │        │                  │
│  iscsi-target (separate)────────┼── root filesystem │
└─────────────────────────┘        └──────────────────┘
```

## Boot Sequence

1. Thin client PXE ROM broadcasts DHCP DISCOVER
2. Server responds with OFFER: thin client IP, server IP, TFTP filename
3. Thin client fetches GRUB bootloader via TFTP
4. GRUB loads its config via HTTP; config contains kernel args with iSCSI details
5. GRUB fetches kernel + initrd via HTTP
6. Kernel boots; initrd connects to iSCSI target and mounts root filesystem
7. Debian runs on thin client

## Quick Start

```bash
cp config.example.toml config.toml
# Edit config.toml for your setup
sudo pxe-boot-server --config config.toml
```

Requires root (or `CAP_NET_BIND_SERVICE`) for UDP ports 67 and 69.

## TFTP Root Layout

The TFTP root directory must contain the GRUB bootloader files.
See `docs/GRUB_SETUP.md` for how to populate this from a Debian system.

## See Also

- `docs/ARCHITECTURE.md` — module design and data flow
- `docs/CONFIG.md` — full TOML reference
- `docs/GRUB_SETUP.md` — preparing GRUB bootloader files
- `docs/ISCSI_KERNEL_ARGS.md` — iSCSI kernel command-line parameter reference
