# iSCSI Kernel Command-Line Parameters

The binary generates these kernel arguments from your `[iscsi]` TOML config.
This document explains what each one does for reference and troubleshooting.

## Parameters Generated

### Network Setup (initrd phase)

```
ip=<client_ip>::<server_ip>:<netmask>::<iface>:none
```

Example:
```
ip=10.11.12.2::10.11.12.1:255.255.255.0::eth0:none
```

Configures the network interface during initrd before iSCSI connects.
Format: `client_ip::gateway:netmask::interface:autoconf`
Gateway is the server IP (our laptop). `none` means no autoconfiguration.

### iSCSI Connection (dracut/initramfs-tools)

These are understood by both dracut and Debian's initramfs-tools with
open-iscsi:

```
ISCSI_INITIATOR=<initiator_iqn>
ISCSI_TARGET_NAME=<target_iqn>
ISCSI_TARGET_IP=<target_ip>
ISCSI_TARGET_PORT=<target_port>
```

### dracut-specific (if using dracut initrd)

```
rd.iscsi.initiator=<initiator_iqn>
rd.iscsi.target.name=<target_iqn>
rd.iscsi.target.ip=<target_ip>
rd.iscsi.target.port=<target_port>
rd.iscsi.target.lun=<lun>
```

The binary emits both sets for maximum compatibility.

### Root Device

```
root=UUID=<root_uuid>
```

The UUID of the filesystem inside the iSCSI image, taken from `root_uuid` in
your TOML config. UUID is unambiguous regardless of how the kernel enumerates
block devices — far more reliable than `/dev/sda` if the thin client has any
local storage.

Find the UUID of your iSCSI image:
```bash
sudo blkid /path/to/image.img
```

If the image contains a partition table rather than a bare filesystem, use a
loop device to inspect it:
```bash
sudo losetup -P /dev/loop0 /path/to/image.img
sudo blkid /dev/loop0p1
sudo losetup -d /dev/loop0
```

## Troubleshooting

### initrd drops to shell

Usually means iSCSI connection failed. Check:
- iSCSI target process is running before booting
- `target_ip` and `target_port` in config match the running target
- The point-to-point link is up on both ends
- IQNs match exactly (case-sensitive)

### Wrong root device

Boot to initrd shell, run `lsblk` to see what block devices are present,
then identify the iSCSI one (it will appear after the iSCSI session connects).
